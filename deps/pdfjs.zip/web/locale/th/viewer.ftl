# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


## Main toolbar buttons (tooltips and alt text for images)

pdfjs-previous-button =
    .title = หน้าก่อนหน้า
pdfjs-previous-button-label = ก่อนหน้า
pdfjs-next-button =
    .title = หน้าถัดไป
pdfjs-next-button-label = ถัดไป
# .title: Tooltip for the pageNumber input.
pdfjs-page-input =
    .title = หน้า
# Variables:
#   $pagesCount (Number) - the total number of pages in the document
# This string follows an input field with the number of the page currently displayed.
pdfjs-of-pages = จาก { $pagesCount }
# Variables:
#   $pageNumber (Number) - the currently visible page
#   $pagesCount (Number) - the total number of pages in the document
pdfjs-page-of-pages = ({ $pageNumber } จาก { $pagesCount })
pdfjs-zoom-out-button =
    .title = ซูมออก
pdfjs-zoom-out-button-label = ซูมออก
pdfjs-zoom-in-button =
    .title = ซูมเข้า
pdfjs-zoom-in-button-label = ซูมเข้า
pdfjs-zoom-select =
    .title = ซูม
pdfjs-presentation-mode-button =
    .title = สลับเป็นโหมดการนำเสนอ
pdfjs-presentation-mode-button-label = โหมดการนำเสนอ
pdfjs-open-file-button =
    .title = เปิดไฟล์
pdfjs-open-file-button-label = เปิด
pdfjs-print-button =
    .title = พิมพ์
pdfjs-print-button-label = พิมพ์
pdfjs-save-button =
    .title = บันทึก
pdfjs-save-button-label = บันทึก
# Used in Firefox for Android as a tooltip for the download button (“download” is a verb).
pdfjs-download-button =
    .title = ดาวน์โหลด
# Used in Firefox for Android as a label for the download button (“download” is a verb).
# Length of the translation matters since we are in a mobile context, with limited screen estate.
pdfjs-download-button-label = ดาวน์โหลด
pdfjs-bookmark-button =
    .title = หน้าปัจจุบัน (ดู URL จากหน้าปัจจุบัน)
pdfjs-bookmark-button-label = หน้าปัจจุบัน

##  Secondary toolbar and context menu

pdfjs-tools-button =
    .title = เครื่องมือ
pdfjs-tools-button-label = เครื่องมือ
pdfjs-first-page-button =
    .title = ไปยังหน้าแรก
pdfjs-first-page-button-label = ไปยังหน้าแรก
pdfjs-last-page-button =
    .title = ไปยังหน้าสุดท้าย
pdfjs-last-page-button-label = ไปยังหน้าสุดท้าย
pdfjs-page-rotate-cw-button =
    .title = หมุนตามเข็มนาฬิกา
pdfjs-page-rotate-cw-button-label = หมุนตามเข็มนาฬิกา
pdfjs-page-rotate-ccw-button =
    .title = หมุนทวนเข็มนาฬิกา
pdfjs-page-rotate-ccw-button-label = หมุนทวนเข็มนาฬิกา
pdfjs-cursor-text-select-tool-button =
    .title = เปิดใช้งานเครื่องมือการเลือกข้อความ
pdfjs-cursor-text-select-tool-button-label = เครื่องมือการเลือกข้อความ
pdfjs-cursor-hand-tool-button =
    .title = เปิดใช้งานเครื่องมือมือ
pdfjs-cursor-hand-tool-button-label = เครื่องมือมือ
pdfjs-scroll-page-button =
    .title = ใช้การเลื่อนหน้า
pdfjs-scroll-page-button-label = การเลื่อนหน้า
pdfjs-scroll-vertical-button =
    .title = ใช้การเลื่อนแนวตั้ง
pdfjs-scroll-vertical-button-label = การเลื่อนแนวตั้ง
pdfjs-scroll-horizontal-button =
    .title = ใช้การเลื่อนแนวนอน
pdfjs-scroll-horizontal-button-label = การเลื่อนแนวนอน
pdfjs-scroll-wrapped-button =
    .title = ใช้การเลื่อนแบบคลุม
pdfjs-scroll-wrapped-button-label = เลื่อนแบบคลุม
pdfjs-spread-none-button =
    .title = ไม่ต้องรวมการกระจายหน้า
pdfjs-spread-none-button-label = ไม่กระจาย
pdfjs-spread-odd-button =
    .title = รวมการกระจายหน้าเริ่มจากหน้าคี่
pdfjs-spread-odd-button-label = กระจายอย่างเหลือเศษ
pdfjs-spread-even-button =
    .title = รวมการกระจายหน้าเริ่มจากหน้าคู่
pdfjs-spread-even-button-label = กระจายอย่างเท่าเทียม

## Document properties dialog

pdfjs-document-properties-button =
    .title = คุณสมบัติเอกสาร…
pdfjs-document-properties-button-label = คุณสมบัติเอกสาร…
pdfjs-document-properties-file-name = ชื่อไฟล์:
pdfjs-document-properties-file-size = ขนาดไฟล์:
# Variables:
#   $kb (Number) - the PDF file size in kilobytes
#   $b (Number) - the PDF file size in bytes
pdfjs-document-properties-size-kb = { NUMBER($kb, maximumSignificantDigits: 3) } KB ({ $b } ไบต์)
# Variables:
#   $mb (Number) - the PDF file size in megabytes
#   $b (Number) - the PDF file size in bytes
pdfjs-document-properties-size-mb = { NUMBER($mb, maximumSignificantDigits: 3) } MB ({ $b } ไบต์)
pdfjs-document-properties-title = ชื่อเรื่อง:
pdfjs-document-properties-author = ผู้สร้าง:
pdfjs-document-properties-subject = ชื่อเรื่อง:
pdfjs-document-properties-keywords = คำสำคัญ:
pdfjs-document-properties-creation-date = วันที่สร้าง:
pdfjs-document-properties-modification-date = วันที่แก้ไข:
# Variables:
#   $dateObj (Date) - the creation/modification date and time of the PDF file
pdfjs-document-properties-date-time-string = { DATETIME($dateObj, dateStyle: "short", timeStyle: "medium") }
pdfjs-document-properties-creator = ผู้สร้าง:
pdfjs-document-properties-producer = ผู้ผลิต PDF:
pdfjs-document-properties-version = รุ่น PDF:
pdfjs-document-properties-page-count = จำนวนหน้า:
pdfjs-document-properties-page-size = ขนาดหน้า:
pdfjs-document-properties-page-size-unit-inches = in
pdfjs-document-properties-page-size-unit-millimeters = mm
pdfjs-document-properties-page-size-orientation-portrait = แนวตั้ง
pdfjs-document-properties-page-size-orientation-landscape = แนวนอน
pdfjs-document-properties-page-size-name-a-three = A3
pdfjs-document-properties-page-size-name-a-four = A4
pdfjs-document-properties-page-size-name-letter = จดหมาย
pdfjs-document-properties-page-size-name-legal = ข้อกฎหมาย

## Variables:
##   $width (Number) - the width of the (current) page
##   $height (Number) - the height of the (current) page
##   $unit (String) - the unit of measurement of the (current) page
##   $name (String) - the name of the (current) page
##   $orientation (String) - the orientation of the (current) page

pdfjs-document-properties-page-size-dimension-string = { $width } × { $height } { $unit } ({ $orientation })
pdfjs-document-properties-page-size-dimension-name-string = { $width } × { $height } { $unit } ({ $name }, { $orientation })

##

# The linearization status of the document; usually called "Fast Web View" in
# English locales of Adobe software.
pdfjs-document-properties-linearized = มุมมองเว็บแบบรวดเร็ว:
pdfjs-document-properties-linearized-yes = ใช่
pdfjs-document-properties-linearized-no = ไม่
pdfjs-document-properties-close-button = ปิด

## Print

pdfjs-print-progress-message = กำลังเตรียมเอกสารสำหรับการพิมพ์…
# Variables:
#   $progress (Number) - percent value
pdfjs-print-progress-percent = { $progress }%
pdfjs-print-progress-close-button = ยกเลิก
pdfjs-printing-not-supported = คำเตือน: เบราว์เซอร์นี้ไม่ได้สนับสนุนการพิมพ์อย่างเต็มที่
pdfjs-printing-not-ready = คำเตือน: PDF ไม่ได้รับการโหลดอย่างเต็มที่สำหรับการพิมพ์

## Tooltips and alt text for side panel toolbar buttons

pdfjs-current-outline-item-button =
    .title = ค้นหารายการเค้าร่างปัจจุบัน
pdfjs-current-outline-item-button-label = รายการเค้าร่างปัจจุบัน
pdfjs-findbar-button =
    .title = ค้นหาในเอกสาร
pdfjs-findbar-button-label = ค้นหา
pdfjs-additional-layers = เลเยอร์เพิ่มเติม

## Thumbnails panel item (tooltip and alt text for images)

# Variables:
#   $page (Number) - the page number
pdfjs-thumb-page-canvas =
    .aria-label = ภาพขนาดย่อของหน้า { $page }
# Variables:
#   $page (Number) - the page number
pdfjs-thumb-page-checkbox1 =
    .title = เลือกหน้า { $page }
# Variables:
#   $page (Number) - the page number
#   $total (Number) - the number of pages
pdfjs-thumb-page-title1 =
    .title = หน้า { $page } จาก { $total }

## Find panel button title and messages

pdfjs-find-input =
    .placeholder = ค้นหาในเอกสาร…
    .title = ค้นหา
pdfjs-find-previous-button =
    .title = หาตำแหน่งก่อนหน้าของวลี
pdfjs-find-previous-button-label = ก่อนหน้า
pdfjs-find-next-button =
    .title = หาตำแหน่งถัดไปของวลี
pdfjs-find-next-button-label = ถัดไป
pdfjs-find-highlight-checkbox = เน้นสีทั้งหมด
pdfjs-find-match-case-checkbox-label = ตัวพิมพ์ใหญ่เล็กตรงกัน
pdfjs-find-match-diacritics-checkbox-label = เครื่องหมายกำกับการออกเสียงตรงกัน
pdfjs-find-entire-word-checkbox-label = ทั้งคำ
pdfjs-find-reached-top = ค้นหาถึงจุดเริ่มต้นของหน้า เริ่มค้นต่อจากด้านล่าง
pdfjs-find-reached-bottom = ค้นหาถึงจุดสิ้นสุดหน้า เริ่มค้นต่อจากด้านบน
# Variables:
#   $current (Number) - the index of the currently active find result
#   $total (Number) - the total number of matches in the document
pdfjs-find-match-count = { $current } จาก { $total } รายการที่ตรงกัน
# Variables:
#   $limit (Number) - the maximum number of matches
pdfjs-find-match-count-limit = มากกว่า { $limit } รายการที่ตรงกัน
pdfjs-find-not-found = ไม่พบวลี

## Predefined zoom values

pdfjs-page-scale-width = ความกว้างหน้า
pdfjs-page-scale-fit = พอดีหน้า
pdfjs-page-scale-auto = ซูมอัตโนมัติ
pdfjs-page-scale-actual = ขนาดจริง
# Variables:
#   $scale (Number) - percent value for page scale
pdfjs-page-scale-percent = { $scale }%

## PDF page

# Variables:
#   $page (Number) - the page number
pdfjs-page-landmark =
    .aria-label = หน้า { $page }

## Loading indicator messages

pdfjs-loading-error = เกิดข้อผิดพลาดขณะโหลด PDF
pdfjs-invalid-file-error = ไฟล์ PDF ไม่ถูกต้องหรือเสียหาย
pdfjs-missing-file-error = ไฟล์ PDF หายไป
pdfjs-unexpected-response-error = การตอบสนองของเซิร์ฟเวอร์ที่ไม่คาดคิด
pdfjs-rendering-error = เกิดข้อผิดพลาดขณะเรนเดอร์หน้า

## Annotations

# .alt: This is used as a tooltip.
# Variables:
#   $type (String) - an annotation type from a list defined in the PDF spec
# (32000-1:2008 Table 169 – Annotation types).
# Some common types are e.g.: "Check", "Text", "Comment", "Note"
pdfjs-text-annotation-type =
    .alt = [คำอธิบายประกอบ { $type }]
# Variables:
#   $dateObj (Date) - the modification date and time of the annotation
pdfjs-annotation-date-time-string = { DATETIME($dateObj, dateStyle: "short", timeStyle: "medium") }

## Password

pdfjs-password-label = ป้อนรหัสผ่านเพื่อเปิดไฟล์ PDF นี้
pdfjs-password-invalid = รหัสผ่านไม่ถูกต้อง โปรดลองอีกครั้ง
pdfjs-password-ok-button = ตกลง
pdfjs-password-cancel-button = ยกเลิก
pdfjs-web-fonts-disabled = แบบอักษรเว็บถูกปิดใช้งาน: ไม่สามารถใช้แบบอักษร PDF ฝังตัว

## Editing

pdfjs-editor-free-text-button =
    .title = ข้อความ
pdfjs-editor-color-picker-free-text-input =
    .title = เปลี่ยนสีข้อความ
pdfjs-editor-free-text-button-label = ข้อความ
pdfjs-editor-ink-button =
    .title = รูปวาด
pdfjs-editor-color-picker-ink-input =
    .title = เปลี่ยนสีรูปวาด
pdfjs-editor-ink-button-label = รูปวาด
pdfjs-editor-stamp-button =
    .title = เพิ่มหรือแก้ไขภาพ
pdfjs-editor-stamp-button-label = เพิ่มหรือแก้ไขภาพ
pdfjs-editor-highlight-button =
    .title = เน้น
pdfjs-editor-highlight-button-label = เน้น
pdfjs-highlight-floating-button1 =
    .aria-label = เน้นสี
    .title = เน้นสี
pdfjs-highlight-floating-button-label = เน้นสี
pdfjs-comment-floating-button =
    .aria-label = แสดงความคิดเห็น
    .title = แสดงความคิดเห็น
pdfjs-comment-floating-button-label = แสดงความคิดเห็น
pdfjs-editor-comment-button =
    .aria-label = แสดงความคิดเห็น
    .title = แสดงความคิดเห็น
pdfjs-editor-comment-button-label = ความคิดเห็น
pdfjs-editor-signature-button =
    .title = เพิ่มลายเซ็น
pdfjs-editor-signature-button-label = เพิ่มลายเซ็น

## Default editor aria labels

# “Highlight” is a noun, the string is used on the editor for highlights.
pdfjs-editor-highlight-editor =
    .aria-label = ตัวแก้ไขสีเน้น
# “Drawing” is a noun, the string is used on the editor for drawings.
pdfjs-editor-ink-editor =
    .aria-label = ตัวแก้ไขรูปวาด
# Used when a signature editor is selected/hovered.
# Variables:
#   $description (String) - a string describing/labeling the signature.
pdfjs-editor-signature-editor1 =
    .aria-description = ตัวแก้ไขลายเซ็น: { $description }
pdfjs-editor-stamp-editor =
    .aria-label = ตัวแก้ไขภาพ

## Remove button for the various kind of editor.

pdfjs-editor-remove-ink-button =
    .title = เอาภาพวาดออก
pdfjs-editor-remove-freetext-button =
    .title = เอาข้อความออก
pdfjs-editor-remove-stamp-button =
    .title = เอาภาพออก
pdfjs-editor-remove-highlight-button =
    .title = เอาการเน้นสีออก
pdfjs-editor-remove-signature-button =
    .title = ลบลายเซ็น

##

# Editor Parameters
pdfjs-editor-free-text-color-input = สี
pdfjs-editor-free-text-size-input = ขนาด
pdfjs-editor-ink-color-input = สี
pdfjs-editor-ink-thickness-input = ความหนา
pdfjs-editor-ink-opacity-input = ความทึบ
pdfjs-editor-stamp-add-image-button =
    .title = เพิ่มภาพ
pdfjs-editor-stamp-add-image-button-label = เพิ่มภาพ
# This refers to the thickness of the line used for free highlighting (not bound to text)
pdfjs-editor-free-highlight-thickness-input = ความหนา
pdfjs-editor-free-highlight-thickness-title =
    .title = เปลี่ยนความหนาเมื่อเน้นรายการอื่นๆ ที่ไม่ใช่ข้อความ
pdfjs-editor-add-signature-container =
    .aria-label = ส่วนควบคุมลายเซ็นและลายเซ็นที่บันทึกไว้
pdfjs-editor-signature-add-signature-button =
    .title = เพิ่มลายเซ็นใหม่
pdfjs-editor-signature-add-signature-button-label = เพิ่มลายเซ็นใหม่
# Used on the button to use an already saved signature.
# Variables:
#   $description (String) - a string describing/labeling the signature.
pdfjs-editor-add-saved-signature-button =
    .title = ลายเซ็นที่บันทึกไว้: { $description }
# .default-content is used as a placeholder in an empty text editor.
pdfjs-free-text2 =
    .aria-label = ตัวแก้ไขข้อความ
    .default-content = เริ่มพิมพ์ได้เลย…
# Used to show how many comments are present in the pdf file.
# Variables:
#   $count (Number) - the number of comments.
pdfjs-editor-comments-sidebar-title = ความคิดเห็น
pdfjs-editor-comments-sidebar-close-button =
    .aria-label = ปิดแถบข้าง
    .title = ปิดแถบข้าง
pdfjs-editor-comments-sidebar-close-button-label = ปิดแถบข้าง
# Instructional copy to add a comment by selecting text or an annotations.
pdfjs-editor-comments-sidebar-no-comments1 = เห็นอะไรที่น่าสนใจใช่ไหม? เน้นสีไว้และแสดงความคิดเห็นได้เลย
pdfjs-editor-comments-sidebar-no-comments-link = เรียนรู้เพิ่มเติม

## Alt-text dialog

pdfjs-editor-alt-text-button-label = ข้อความทดแทน
pdfjs-editor-alt-text-edit-button =
    .aria-label = แก้ไขข้อความทดแทน
pdfjs-editor-alt-text-dialog-label = เลือกตัวเลือก
pdfjs-editor-alt-text-dialog-description = ข้อความทดแทนสามารถช่วยเหลือได้เมื่อผู้ใช้มองไม่เห็นภาพ หรือภาพไม่โหลด
pdfjs-editor-alt-text-add-description-label = เพิ่มคำอธิบาย
pdfjs-editor-alt-text-add-description-description = แนะนำให้ใช้ 1-2 ประโยคซึ่งอธิบายหัวเรื่อง ฉาก หรือการกระทำ
pdfjs-editor-alt-text-mark-decorative-label = ทำเครื่องหมายเป็นสิ่งตกแต่ง
pdfjs-editor-alt-text-mark-decorative-description = สิ่งนี้ใช้สำหรับภาพที่เป็นสิ่งประดับ เช่น ขอบ หรือลายน้ำ
pdfjs-editor-alt-text-cancel-button = ยกเลิก
pdfjs-editor-alt-text-save-button = บันทึก
pdfjs-editor-alt-text-decorative-tooltip = ทำเครื่องหมายเป็นสิ่งตกแต่งแล้ว
# .placeholder: This is a placeholder for the alt text input area
pdfjs-editor-alt-text-textarea =
    .placeholder = ตัวอย่างเช่น “ชายหนุ่มคนหนึ่งนั่งลงที่โต๊ะเพื่อรับประทานอาหารมื้อหนึ่ง”
# Alternative text (alt text) helps when people can't see the image.
pdfjs-editor-alt-text-button =
    .aria-label = ข้อความทดแทน

## Editor resizers
## This is used in an aria label to help to understand the role of the resizer.

pdfjs-editor-resizer-top-left =
    .aria-label = มุมซ้ายบน — ปรับขนาด
pdfjs-editor-resizer-top-middle =
    .aria-label = ตรงกลางด้านบน — ปรับขนาด
pdfjs-editor-resizer-top-right =
    .aria-label = มุมขวาบน — ปรับขนาด
pdfjs-editor-resizer-middle-right =
    .aria-label = ตรงกลางด้านขวา — ปรับขนาด
pdfjs-editor-resizer-bottom-right =
    .aria-label = มุมขวาล่าง — ปรับขนาด
pdfjs-editor-resizer-bottom-middle =
    .aria-label = ตรงกลางด้านล่าง — ปรับขนาด
pdfjs-editor-resizer-bottom-left =
    .aria-label = มุมซ้ายล่าง — ปรับขนาด
pdfjs-editor-resizer-middle-left =
    .aria-label = ตรงกลางด้านซ้าย — ปรับขนาด

## Color picker

# This means "Color used to highlight text"
pdfjs-editor-highlight-colorpicker-label = สีเน้น
pdfjs-editor-colorpicker-button =
    .title = เปลี่ยนสี
pdfjs-editor-colorpicker-dropdown =
    .aria-label = ทางเลือกสี
pdfjs-editor-colorpicker-yellow =
    .title = เหลือง
pdfjs-editor-colorpicker-green =
    .title = เขียว
pdfjs-editor-colorpicker-blue =
    .title = น้ำเงิน
pdfjs-editor-colorpicker-pink =
    .title = ชมพู
pdfjs-editor-colorpicker-red =
    .title = แดง

## Show all highlights
## This is a toggle button to show/hide all the highlights.

pdfjs-editor-highlight-show-all-button-label = แสดงทั้งหมด
pdfjs-editor-highlight-show-all-button =
    .title = แสดงทั้งหมด

## New alt-text dialog
## Group note for entire feature: Alternative text (alt text) helps when people can't see the image. This feature includes a tool to create alt text automatically using an AI model that works locally on the user's device to preserve privacy.

# Modal header positioned above a text box where users can edit the alt text.
pdfjs-editor-new-alt-text-dialog-edit-label = แก้ไขข้อความทดแทน (คำอธิบายภาพ)
# Modal header positioned above a text box where users can add the alt text.
pdfjs-editor-new-alt-text-dialog-add-label = เพิ่มข้อความทดแทน (คำอธิบายภาพ)
pdfjs-editor-new-alt-text-textarea =
    .placeholder = เขียนคำอธิบายของคุณที่นี่…
# This text refers to the alt text box above this description. It offers a definition of alt text.
pdfjs-editor-new-alt-text-description = คำอธิบายสั้นๆ สำหรับผู้ที่ไม่สามารถมองเห็นภาพหรือเมื่อภาพไม่โหลด
# This is a required legal disclaimer that refers to the automatically created text inside the alt text box above this text. It disappears if the text is edited by a human.
pdfjs-editor-new-alt-text-disclaimer1 = ข้อความทดแทนนี้ถูกสร้างขึ้นโดยอัตโนมัติและอาจไม่ถูกต้อง
pdfjs-editor-new-alt-text-disclaimer-learn-more-url = เรียนรู้เพิ่มเติม
pdfjs-editor-new-alt-text-create-automatically-button-label = สร้างข้อความทดแทนโดยอัตโนมัติ
pdfjs-editor-new-alt-text-not-now-button = ไม่ใช่ตอนนี้
pdfjs-editor-new-alt-text-error-title = ไม่สามารถสร้างข้อความทดแทนโดยอัตโนมัติได้
pdfjs-editor-new-alt-text-error-description = กรุณาเขียนข้อความทดแทนด้วยตัวเองหรือลองใหม่อีกครั้งในภายหลัง
pdfjs-editor-new-alt-text-error-close-button = ปิด
# Variables:
#   $totalSize (Number) - the total size (in MB) of the AI model.
#   $downloadedSize (Number) - the downloaded size (in MB) of the AI model.
pdfjs-editor-new-alt-text-ai-model-downloading-progress = กำลังดาวน์โหลดโมเดล AI สำหรับข้อความทดแทน ({ $downloadedSize } จาก { $totalSize } MB)
    .aria-valuetext = กำลังดาวน์โหลดโมเดล AI สำหรับข้อความทดแทน ({ $downloadedSize } จาก { $totalSize } MB)
# This is a button that users can click to edit the alt text they have already added.
pdfjs-editor-new-alt-text-added-button =
    .aria-label = เพิ่มข้อความทดแทนแล้ว
pdfjs-editor-new-alt-text-added-button-label = เพิ่มข้อความทดแทนแล้ว
# This is a button that users can click to open the alt text editor and add alt text when it is not present.
pdfjs-editor-new-alt-text-missing-button =
    .aria-label = ขาดข้อความทดแทน
pdfjs-editor-new-alt-text-missing-button-label = ขาดข้อความทดแทน
# This is a button that opens up the alt text modal where users should review the alt text that was automatically generated.
pdfjs-editor-new-alt-text-to-review-button =
    .aria-label = ตรวจสอบข้อความทดแทน
pdfjs-editor-new-alt-text-to-review-button-label = ตรวจสอบข้อความทดแทน
# "Created automatically" is a prefix that will be added to the beginning of any alt text that has been automatically generated. After the colon, the user will see/hear the actual alt text description. If the alt text has been edited by a human, this prefix will not appear.
# Variables:
#   $generatedAltText (String) - the generated alt-text.
pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer = สร้างขึ้นโดยอัตโนมัติ: { $generatedAltText }

## Image alt-text settings

pdfjs-image-alt-text-settings-button =
    .title = ตั้งค่าข้อความทดแทนภาพ
pdfjs-image-alt-text-settings-button-label = ตั้งค่าข้อความทดแทนภาพ
pdfjs-editor-alt-text-settings-dialog-label = ตั้งค่าข้อความทดแทนภาพ
pdfjs-editor-alt-text-settings-automatic-title = การทดแทนด้วยข้อความอัตโนมัติ
pdfjs-editor-alt-text-settings-create-model-button-label = สร้างข้อความทดแทนอัตโนมัติ
pdfjs-editor-alt-text-settings-create-model-description = แนะนำคำอธิบายเพื่อช่วยเหลือผู้ที่ไม่สามารถมองเห็นภาพหรือเมื่อภาพไม่โหลด
pdfjs-editor-alt-text-settings-editor-title = ตัวแก้ไขข้อความทดแทน
pdfjs-editor-alt-text-settings-show-dialog-button-label = แสดงตัวแก้ไขข้อความทดแทนทันทีเมื่อเพิ่มภาพ
pdfjs-editor-alt-text-settings-show-dialog-description = ช่วยให้คุณแน่ใจว่าภาพทั้งหมดของคุณมีข้อความทดแทน
pdfjs-editor-alt-text-settings-close-button = ปิด

## Accessibility labels (announced by screen readers) for objects added to the editor.

pdfjs-editor-highlight-added-alert = เพิ่มการเน้นสีแล้ว
pdfjs-editor-freetext-added-alert = เพิ่มข้อความแล้ว
pdfjs-editor-ink-added-alert = เพิ่มรูปวาดแล้ว
pdfjs-editor-stamp-added-alert = เพิ่มภาพแล้ว
pdfjs-editor-signature-added-alert = เพิ่มลายเซ็นแล้ว

## "Annotations removed" bar

pdfjs-editor-undo-bar-message-highlight = เอาการเน้นสีออกแล้ว
pdfjs-editor-undo-bar-message-freetext = เอาข้อความออกแล้ว
pdfjs-editor-undo-bar-message-ink = เอาภาพวาดออกแล้ว
pdfjs-editor-undo-bar-message-stamp = เอาภาพออกแล้ว
pdfjs-editor-undo-bar-message-signature = ลบลายเซ็นแล้ว
pdfjs-editor-undo-bar-message-comment = เอาความคิดเห็นออกแล้ว
# Variables:
#   $count (Number) - the number of removed annotations.
pdfjs-editor-undo-bar-message-multiple = เอาคำอธิบายประกอบ { $count } รายการออกแล้ว
pdfjs-editor-undo-bar-undo-button =
    .title = เลิกทำ
pdfjs-editor-undo-bar-undo-button-label = เลิกทำ
pdfjs-editor-undo-bar-close-button =
    .title = ปิด
pdfjs-editor-undo-bar-close-button-label = ปิด

## Add a signature dialog

pdfjs-editor-add-signature-dialog-label = โมดัลนี้ช่วยให้ผู้ใช้สามารถสร้างลายเซ็นเพื่อใช้เพิ่มลงในเอกสาร PDF ได้ ผู้ใช้สามารถแก้ไขชื่อ (ซึ่งใช้เป็นข้อความทดแทนได้ด้วย) และสามารถเลือกบันทึกลายเซ็นเพื่อใช้งานซ้ำได้
pdfjs-editor-add-signature-dialog-title = เพิ่มลายเซ็น

## Tab names

# Type is a verb (you can type your name as signature)
pdfjs-editor-add-signature-type-button = พิมพ์
    .title = พิมพ์
# Draw is a verb (you can draw your signature)
pdfjs-editor-add-signature-draw-button = วาด
    .title = วาด
pdfjs-editor-add-signature-image-button = ภาพ
    .title = ภาพ

## Tab panels

pdfjs-editor-add-signature-type-input =
    .aria-label = พิมพ์ลายเซ็นของคุณ
    .placeholder = พิมพ์ลายเซ็นของคุณ
pdfjs-editor-add-signature-draw-placeholder = วาดลายเซ็นของคุณ
pdfjs-editor-add-signature-draw-thickness-range-label = ความหนา
# Variables:
#   $thickness (Number) - the thickness (in pixels) of the line used to draw a signature.
pdfjs-editor-add-signature-draw-thickness-range =
    .title = ความหนาของการวาด: { $thickness }
pdfjs-editor-add-signature-image-placeholder = ลากไฟล์มาที่นี่เพื่ออัปโหลด
pdfjs-editor-add-signature-image-browse-link =
    { PLATFORM() ->
        [macos] หรือเลือกไฟล์ภาพ
       *[other] หรือเรียกดูไฟล์ภาพ
    }

## Controls

pdfjs-editor-add-signature-description-label = คำอธิบาย (ข้อความทดแทน)
pdfjs-editor-add-signature-description-input =
    .title = คำอธิบาย (ข้อความทดแทน)
pdfjs-editor-add-signature-description-default-when-drawing = ลายเซ็น
pdfjs-editor-add-signature-clear-button-label = ล้างลายเซ็น
pdfjs-editor-add-signature-clear-button =
    .title = ล้างลายเซ็น
pdfjs-editor-add-signature-save-checkbox = บันทึกลายเซ็น
pdfjs-editor-add-signature-save-warning-message = คุณมีลายเซ็นที่บันทึกถึงจำนวนสูงสุด 5 รายการแล้ว โปรดลบรายการหนึ่งออกเมื่อจะบันทึกเพิ่ม
pdfjs-editor-add-signature-image-upload-error-title = ไม่สามารถอัปโหลดภาพได้
pdfjs-editor-add-signature-image-upload-error-description = ตรวจสอบการเชื่อมต่อเครือข่ายของคุณหรือลองใช้ภาพอื่น
pdfjs-editor-add-signature-image-no-data-error-title = ไม่สามารถแปลงภาพนี้ให้เป็นลายเซ็นได้
pdfjs-editor-add-signature-image-no-data-error-description = โปรดลองอัปโหลดภาพอื่น
pdfjs-editor-add-signature-error-close-button = ปิด

## Dialog buttons

pdfjs-editor-add-signature-cancel-button = ยกเลิก
pdfjs-editor-add-signature-add-button = เพิ่ม
pdfjs-editor-edit-signature-update-button = อัปเดต

## Comment popup

pdfjs-editor-edit-comment-popup-button-label = แก้ไขความคิดเห็น
pdfjs-editor-edit-comment-popup-button =
    .title = แก้ไขความคิดเห็น
pdfjs-editor-delete-comment-popup-button-label = เอาความคิดเห็นออก
pdfjs-editor-delete-comment-popup-button =
    .title = เอาความคิดเห็นออก
pdfjs-show-comment-button =
    .title = แสดงความคิดเห็น

##  Edit a comment dialog

# An existing comment is edited
pdfjs-editor-edit-comment-dialog-title-when-editing = แก้ไขความคิดเห็น
pdfjs-editor-edit-comment-dialog-save-button-when-editing = อัปเดต
# No existing comment
pdfjs-editor-edit-comment-dialog-title-when-adding = เพิ่มความคิดเห็น
pdfjs-editor-edit-comment-dialog-save-button-when-adding = เพิ่ม
pdfjs-editor-edit-comment-dialog-text-input =
    .placeholder = เริ่มพิมพ์…
pdfjs-editor-edit-comment-dialog-cancel-button = ยกเลิก

## Edit a comment button in the editor toolbar

pdfjs-editor-add-comment-button =
    .title = เพิ่มความคิดเห็น

## The view manager is a sidebar displaying different views:
##  - thumbnails;
##  - outline;
##  - attachments;
##  - layers.
## The thumbnails view is used to edit the pdf: remove/insert pages, ...

pdfjs-toggle-views-manager-notification-button =
    .title = เปิด/ปิดแถบข้าง (เอกสารมีภาพย่อ/เค้าร่าง/ไฟล์แนบ/เลเยอร์)
pdfjs-toggle-views-manager-button1-label = จัดการหน้า
pdfjs-views-manager-sidebar =
    .aria-label = แถบข้าง
pdfjs-views-manager-sidebar-resizer =
    .aria-label = ตัวปรับขนาดแถบข้าง
pdfjs-views-manager-view-selector-button =
    .title = มุมมอง
pdfjs-views-manager-view-selector-button-label = มุมมอง
pdfjs-views-manager-pages-title = หน้า
pdfjs-views-manager-outlines-title1 = โครงร่างเอกสาร
    .title = โครงร่างเอกสาร (คลิกสองครั้งเพื่อขยาย/ยุบรายการทั้งหมด)
pdfjs-views-manager-attachments-title = ไฟล์แนบ
pdfjs-views-manager-layers-title1 = เลเยอร์
    .title = เลเยอร์ (คลิกสองครั้งเพื่อล้างค่าเลเยอร์ทั้งหมดกลับสู่สถานะเริ่มต้น)
pdfjs-views-manager-pages-option-label = หน้า
pdfjs-views-manager-outlines-option-label = เค้าร่างเอกสาร
pdfjs-views-manager-attachments-option-label = ไฟล์แนบ
pdfjs-views-manager-layers-option-label = เลเยอร์
pdfjs-views-manager-add-file-button =
    .title = เพิ่มไฟล์
pdfjs-views-manager-add-file-button-label = เพิ่มไฟล์
# Variables:
#   $count (Number) - the number of selected pages.
pdfjs-views-manager-pages-status-action-label = เลือกอยู่ { $count }
pdfjs-views-manager-pages-status-none-action-label = เลือกหน้า
pdfjs-views-manager-pages-status-action-button-label = จัดการ
pdfjs-views-manager-pages-status-copy-button-label = คัดลอก
pdfjs-views-manager-pages-status-cut-button-label = ตัด
pdfjs-views-manager-pages-status-delete-button-label = ลบ
pdfjs-views-manager-pages-status-export-selected-button-label = ส่งออกรายการที่เลือก…
# Variables:
#   $count (Number) - the number of selected pages to be cut.
pdfjs-views-manager-status-undo-cut-label = ตัด { $count } หน้าแล้ว
# Variables:
#   $count (Number) - the number of selected pages to be copied.
pdfjs-views-manager-pages-status-undo-copy-label = คัดลอก { $count } หน้าแล้ว
# Variables:
#   $count (Number) - the number of selected pages to be deleted.
pdfjs-views-manager-pages-status-undo-delete-label = ลบ { $count } หน้าแล้ว
pdfjs-views-manager-pages-status-waiting-ready-label = กำลังเตรียมไฟล์ของคุณให้พร้อม…
pdfjs-views-manager-pages-status-waiting-uploading-label = กำลังอัปโหลดไฟล์…
pdfjs-views-manager-status-warning-cut-label = ไม่สามารถตัดได้ โปรดรีเฟรชหน้าแล้วลองอีกครั้ง
pdfjs-views-manager-status-warning-copy-label = ไม่สามารถคัดลอกได้ โปรดรีเฟรชหน้าแล้วลองอีกครั้ง
pdfjs-views-manager-status-warning-delete-label = ไม่สามารถลบได้ โปรดรีเฟรชหน้าแล้วลองอีกครั้ง
pdfjs-views-manager-status-warning-save-label = ไม่สามารถบันทึกได้ โปรดรีเฟรชหน้าแล้วลองอีกครั้ง
pdfjs-views-manager-status-undo-button-label = เลิกทำ
pdfjs-views-manager-status-done-button-label = เสร็จสิ้น
pdfjs-views-manager-status-close-button =
    .title = ปิด
pdfjs-views-manager-status-close-button-label = ปิด
pdfjs-views-manager-paste-button-label = วาง
pdfjs-views-manager-paste-button-before =
    .title = วางก่อนหน้าแรก
# Variables:
#   $page (Number) - the page number after which the paste button is.
pdfjs-views-manager-paste-button-after =
    .title = วางหลังหน้า { $page }
# Badge used to promote a new feature in the UI, keep it as short as possible.
# It's spelled uppercase for English, but it can be translated as usual.
pdfjs-new-badge-content = ใหม่
pdfjs-views-manager-waiting-for-file = กำลังอัปโหลดไฟล์…
pdfjs-toggle-views-manager-button1 =
    .title = จัดการหน้า

## Main menu for adding/removing signatures

pdfjs-editor-delete-signature-button1 =
    .title = ลบลายเซ็นที่บันทึกไว้
pdfjs-editor-delete-signature-button-label1 = ลบลายเซ็นที่บันทึกไว้

## Editor toolbar

pdfjs-editor-add-signature-edit-button-label = แก้ไขคำอธิบาย

## Edit signature description dialog

pdfjs-editor-edit-signature-dialog-title = แก้ไขคำอธิบาย
